package config

type Threshold interface {
	ThresholdKeyShare() string
}
